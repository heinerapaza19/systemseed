@props(['from' => 'login', 'label' => 'Continuar con Google'])
{{-- Botón de acceso con Google: crea la cuenta si no existe o inicia sesión si ya existe --}}
<a href="{{ route('google.redirect', ['from' => $from === 'register' ? 'registro' : null]) }}"
   x-data="{ going: false }" @click="going = true" @pageshow.window="going = false" :class="going && 'pointer-events-none opacity-80'"
   {{ $attributes->merge(['class' => 'flex w-full items-center justify-center gap-3 rounded-2xl border border-white/15 bg-white px-5 py-3.5 text-sm font-bold text-slate-800 shadow-sm transition hover:-translate-y-0.5 hover:bg-slate-50 hover:shadow-lg focus:outline-none focus-visible:ring-2 focus-visible:ring-seed-lime/60']) }}>
    <svg x-show="!going" width="20" height="20" viewBox="0 0 48 48" aria-hidden="true">
        <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/>
        <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
        <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z"/>
        <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/>
    </svg>
    <span x-show="going" x-cloak class="h-5 w-5 animate-spin rounded-full border-2 border-slate-300 border-t-slate-700"></span>
    <span x-text="going ? 'Conectando con Google…' : @js($label)">{{ $label }}</span>
</a>
